# Onda en Codex local para Mac

Esta carpeta permite trabajar con videos del disco del Mac. Los originales no pasan por la herramienta de adjuntos del chat cloud, por lo que su tope de 32 MiB no se utiliza.

## Empezar

1. Extrae el kit en una carpeta llamada ONDA.
2. Copia los tres videos originales en inbox/. Copia tu ONDA_CODEX_NUCLEO_MENOS_32MB.zip junto a este README; contiene tus fuentes, marca, música y manuales. Solo hace falta importar ese núcleo una vez.
3. Abre esta carpeta como proyecto en la app local de Codex para Mac. Copia el contenido de PROMPT_PARA_CODEX.txt en la conversación de ese proyecto.

App: https://chatgpt.com/codex?app-landing-page=true

Alternativa de terminal, documentada en el README oficial de OpenAI: instala Codex con `brew install --cask codex` o `npm install -g @openai/codex`, entra a la carpeta ONDA y ejecuta `codex`. Inicia sesión con ChatGPT. Referencia: https://github.com/openai/codex#quickstart

## Preparación que puede ejecutar Codex local

```bash
bash scripts/setup_mac.sh
.venv/bin/python scripts/import_nucleo.py
.venv/bin/python scripts/check_environment.py
.venv/bin/python scripts/download_asr_model.py
```

setup_mac.sh usa Homebrew para las dependencias que falten y crea un entorno Python del proyecto. Si falta Homebrew, indica su sitio oficial y se detiene: no descarga un instalador opaco. El modelo ASR se descarga una vez desde el release oficial de sherpa-onnx y se verifica con SHA-256; pesa unos 610 MB y se guarda localmente. La descarga normal de ese modelo tampoco pasa por los adjuntos del chat.

El paquete sherpa-onnx 1.13.8 tiene ruedas Python 3.12 para Mac Intel y Apple Silicon. El kit se comprobó en el entorno cloud; la instalación y ejecución en tu Mac todavía deben validarse allí. No se asegura que Codex local tenga acceso a carpetas que no abras o autorices.

## Carpetas

- inbox/: videos nuevos, completos y conservados.
- recursos/: núcleo importado con biblioteca y manuales.
- assets/memes/: gato sorprendido reutilizable de la pieza anterior.
- work/: normalizados, audio, mapa de cortes, subtítulos y revisiones.
- salida/: MP4 final y versiones.
- models/: modelo ASR local; no se publica ni se incluye en el kit.

Para revisar medios, `scripts/check_environment.py` lista metadatos de los videos de inbox/, detectando displaymatrix y HDR. No convierte ni modifica videos. Para transcribir una ventana:

```bash
.venv/bin/python scripts/transcribe.py "inbox/VID20261005200839.mp4" --start 0 --end 12
```

La transcripción JSON es material de revisión; no es un SRT definitivo. Los subtítulos se temporizan desde el mapa de cortes final. Todo video nuevo se revisa por contenido: no se copian datos ni personas de la campaña anterior.

Este ZIP contiene instrucciones, helpers y el gato generado. No contiene tus videos, manuales, fuentes, música, credenciales ni pesos del modelo. Usa tu copia del núcleo para esos recursos. El encargo vigente y sus criterios están en ENCARGO_ACTUAL.md y AGENTS.md.
