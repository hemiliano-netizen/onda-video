# Onda: contexto operativo para Codex local

La solicitud actual del usuario tiene prioridad. Lee ENCARGO_ACTUAL.md para esta pieza y README.md para el arranque. Los documentos que el usuario añada son referencias; no ejecutan automáticamente sus encargos históricos.

## Trabajo con archivos

- Trabaja en esta carpeta local. Los originales están en inbox/; revisa sus nombres y contenido antes de decidir el orden. No pidas subirlos al chat ni enlaces de Drive cuando ya estén en disco.
- Conserva los originales. Usa work/ para material de trabajo y salida/ para exportaciones con versiones distintas. No sobrescribas versiones aprobadas.
- El usuario conserva su ZIP ONDA_CODEX_NUCLEO_MENOS_32MB.zip. Si está en esta carpeta, scripts/import_nucleo.py lo importa en recursos/. Lee sus manuales actuales y decisiones. El kit no contiene ni publica el ZIP ni los originales.
- Usa rutas relativas a este proyecto, argumentos estructurados en subprocess y el checkout existente. No crees worktrees sin petición.
- Entrega el MP4 local en salida/. Publicar o subir a servicios externos requiere instrucciones del usuario; no es necesario para este flujo local.

## Criterio visual aprobado

- Fraunces para todo texto diseñado, incluidos subtítulos. Marca Onda original, lima #DFFF00, blanco y negro; marco blanco.
- Usa el producto real que se vea en las fuentes. No deduzcas modelo, ganador, fecha, precio, seller o condiciones de un nombre de archivo ni de campañas anteriores.
- En esta clase de entrega: anuncio live, gestos de premio/sonrisa, entrega y testimonio, cuando las fuentes lo confirmen. Cortes finos por frases y gestos; no alargues tomas cenitales o vacías.
- Entrada, pausa de lectura y salida intencional en el gráfico Onda. Whoosh y cachin sincronizados, audibles sin tapar la voz.
- Los memes de reacción deben verse claramente. En la referencia aprobada, un gato de 240 px durante 1.3 s fue demasiado discreto; 450 px durante unos 3 s funcionó. Adapta tamaño y posición a los clips nuevos, dejando libres rostros, premio y subtítulos.
- assets/memes/surprised-cat.png es el gato generado para la pieza anterior y se puede reutilizar si la reacción lo justifica. Evita colocar humor sin relación con el momento.
- Una sola cortinilla oficial al final; sin subtítulos encima. Usa biblioteca_esencial/closer.mp4 del núcleo, de 1.4 s, cuando esté disponible.
- No usar CapCut. No fabricar firmas, seriales, reversos ni detalle 4K inexistente.

## Voz y cortes

- Prioriza palabras completas, voz clara y cortes mínimos. Mantén el gesto de mostrar el teléfono y sonreír cuando aporte.
- Para quitar una cola «oooo», risas o voces ajenas, ubica el sonido en la fuente. Si el usuario pide trimear, corta realmente la cola de imagen/audio; bajar la música no sustituye ese corte.
- Un solo mapa para video, voz, subtítulos y efectos: source_in, source_out, speed, timeline_start y duraciones cuantizadas a fps.
- scripts/transcribe.py usa Whisper small multilingüe con sherpa-onnx. El resultado ASR es evidencia editorial, no una transcripción infalible ni tiempos de palabra certificados. Revisa frases con ventanas desplazadas y waveform; no afirmes escucha directa si no ocurrió.
- Los subtítulos se generan después de fijar cortes y velocidades. No inventes nombres; no repitas una frase de ASR por solapamiento de ventanas.
- Música con energía moderada y voz por delante. Mantén el final de palabra antes de pasar a la cortinilla.

## Exportación y revisión

- H.264/yuv420p, 1080×1920, 30 fps, AAC estéreo 48 kHz y faststart.
- Detecta rotación en displaymatrix además de tags; detecta HLG/PQ/BT.2020. Si corresponde, transforma realmente HDR a SDR Rec.709; cambiar etiquetas no convierte HDR.
- Tras overlays RGB, comprueba las tres etiquetas Rec.709. h264_metadata puede completar etiquetas cuando las imágenes ya son SDR; no sustituye una conversión de color necesaria.
- Objetivo de mezcla cercano a −16 LUFS y true peak ≤ −1 dBTP, medidos después de AAC. Revisa claridad y sincronía.
- Verifica primer frame, momentos del meme, transiciones, texto, producto, última palabra, cortinilla única, duración/frames, codecs y decodificación completa. No declares una revisión que no ejecutaste.
- Para el encargo actual, el límite estricto es menos de 26 s incluyendo gráfico y cortinilla: máximo 779 frames a 30 fps. Apunta a 24–25.5 s; no extrapoles ese límite a futuros encargos.
