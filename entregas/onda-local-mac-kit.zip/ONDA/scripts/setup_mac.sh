#!/usr/bin/env bash
# Run on the user's Mac. This script is not a Homebrew installer.
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Este script es para macOS. No se instalará nada en este sistema." >&2
  exit 2
fi

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_root"

if ! command -v brew >/dev/null 2>&1; then
  for brew_directory in /opt/homebrew/bin /usr/local/bin; do
    if [[ -x "$brew_directory/brew" ]]; then
      export PATH="$brew_directory:$PATH"
      break
    fi
  done
fi

need_brew() {
  if ! command -v brew >/dev/null 2>&1; then
    echo "Falta Homebrew. Instálalo siguiendo https://brew.sh y vuelve a ejecutar este script." >&2
    exit 1
  fi
}

python_bin=""
for candidate in python3.12 python3; do
  if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] == (3,12) else 1)' >/dev/null 2>&1; then
    python_bin="$(command -v "$candidate")"
    break
  fi
done
if [[ -z "$python_bin" ]]; then
  need_brew
  brew install python@3.12
  python_bin="$(brew --prefix python@3.12)/bin/python3.12"
fi

ffmpeg_ok=false
if command -v ffmpeg >/dev/null 2>&1 && command -v ffprobe >/dev/null 2>&1; then
  if "$python_bin" - <<'PY'
import subprocess
def names(option):
    result = subprocess.run(['ffmpeg', '-hide_banner', option], capture_output=True, text=True)
    if result.returncode:
        return set()
    return {fields[1] for line in result.stdout.splitlines()
            if len(fields := line.split()) >= 2 and len(fields[0]) in (3, 6)}
raise SystemExit(0 if {'drawtext', 'zscale', 'tonemap', 'loudnorm'} <= names('-filters')
                 and {'libx264', 'aac'} <= names('-encoders') else 1)
PY
  then
    ffmpeg_ok=true
  fi
fi
if [[ "$ffmpeg_ok" != true ]]; then
  need_brew
  brew install ffmpeg
  export PATH="$(brew --prefix)/bin:$PATH"
fi

if [[ -L .venv ]]; then
  echo "La .venv existente es un enlace simbólico. Consérvala y utiliza una carpeta de proyecto nueva." >&2
  exit 1
fi
if [[ ! -d .venv ]]; then
  "$python_bin" -m venv .venv
fi
if [[ ! -x .venv/bin/python ]]; then
  echo "La carpeta .venv existente no es un entorno válido de macOS. Consérvala y usa una carpeta de proyecto nueva." >&2
  exit 1
fi
if ! .venv/bin/python -c 'import sys; raise SystemExit(0 if sys.prefix != sys.base_prefix and sys.version_info[:2] == (3,12) else 1)'; then
  echo "La .venv existente usa una versión incompatible. Consérvala y utiliza una carpeta de proyecto nueva." >&2
  exit 1
fi
if [[ ! -f requirements.txt ]]; then
  echo "Falta requirements.txt en el kit; vuelve a extraer el paquete completo." >&2
  exit 1
fi
.venv/bin/python -m pip install -r requirements.txt
mkdir -p inbox salida recursos work
.venv/bin/python scripts/check_environment.py
echo "Entorno listo. Copia los originales en inbox e importa tu ZIP núcleo con .venv/bin/python scripts/import_nucleo.py."
