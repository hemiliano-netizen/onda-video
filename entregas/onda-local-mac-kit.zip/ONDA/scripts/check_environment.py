#!/usr/bin/env python3
"""Inspect a local Onda workspace without changing media or downloading tools."""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

VIDEO_EXTENSIONS = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi"}
REQUIRED_FILTERS = {"drawtext", "zscale", "tonemap", "loudnorm"}
REQUIRED_ENCODERS = {"libx264", "aac"}


def run(arguments, timeout=30):
    result = subprocess.run(arguments, capture_output=True, text=True, timeout=timeout)
    if result.returncode:
        raise RuntimeError(f"{Path(arguments[0]).name} terminó con código {result.returncode}")
    return result.stdout


def capability_names(text):
    names = set()
    for line in text.splitlines():
        fields = line.split()
        if len(fields) >= 2 and len(fields[0]) in (3, 6):
            names.add(fields[1])
    return names


def inspect_media(path, project):
    entries = (
        "format=duration,size:stream=index,codec_type,codec_name,width,height,pix_fmt,"
        "r_frame_rate,avg_frame_rate,sample_rate,channels,color_space,color_transfer,"
        "color_primaries:stream_tags=rotate:stream_side_data=rotation"
    )
    raw = json.loads(run(["ffprobe", "-v", "error", "-show_entries", entries,
                          "-of", "json", str(path)], timeout=60))
    video = next((s for s in raw.get("streams", []) if s.get("codec_type") == "video"), None)
    if video is None:
        raise RuntimeError("No contiene una pista de video")
    rotation = video.get("tags", {}).get("rotate", 0)
    for side_data in video.get("side_data_list", []):
        if "rotation" in side_data:
            rotation = side_data["rotation"]
    rotation = float(rotation)
    width, height = video.get("width"), video.get("height")
    if width and height and round(rotation) % 180:
        width, height = height, width
    transfer = video.get("color_transfer")
    hdr = transfer in {"arib-std-b67", "smpte2084"}
    return {
        "file": str(path.relative_to(project)),
        "duration_seconds": float(raw.get("format", {}).get("duration", 0)),
        "bytes": int(raw.get("format", {}).get("size", path.stat().st_size)),
        "video_codec": video.get("codec_name"),
        "stored_dimensions": [video.get("width"), video.get("height")],
        "display_dimensions": [width, height],
        "rotation_degrees": rotation,
        "frame_rate": video.get("avg_frame_rate"),
        "pixel_format": video.get("pix_fmt"),
        "color_transfer": transfer,
        "color_primaries": video.get("color_primaries"),
        "hdr_detected": hdr,
        "requires_hdr_to_sdr_conversion": hdr,
        "has_audio": any(s.get("codec_type") == "audio" for s in raw.get("streams", [])),
    }


def check(project):
    report = {"project": str(project), "python": sys.version.split()[0],
              "tools": {}, "media": [], "errors": [], "notes": []}
    if sys.version_info < (3, 10):
        report["errors"].append("Se requiere Python 3.10 o posterior")
    for tool in ("ffmpeg", "ffprobe"):
        if not shutil.which(tool):
            report["errors"].append(f"Falta {tool} en PATH")
            continue
        try:
            report["tools"][tool] = run([tool, "-version"]).splitlines()[0]
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as error:
            report["errors"].append(str(error))
    if "ffmpeg" in report["tools"]:
        try:
            filters = capability_names(run(["ffmpeg", "-hide_banner", "-filters"]))
            encoders = capability_names(run(["ffmpeg", "-hide_banner", "-encoders"]))
            report["filters"] = {name: name in filters for name in sorted(REQUIRED_FILTERS)}
            report["encoders"] = {name: name in encoders for name in sorted(REQUIRED_ENCODERS)}
            report["optional_filters"] = {name: name in filters for name in ("subtitles", "sidechaincompress")}
            for name in sorted(REQUIRED_FILTERS - filters):
                report["errors"].append(f"FFmpeg no incluye el filtro {name}")
            for name in sorted(REQUIRED_ENCODERS - encoders):
                report["errors"].append(f"FFmpeg no incluye el codificador {name}")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as error:
            report["errors"].append(str(error))
    inbox = project / "inbox"
    paths = sorted(p for p in inbox.iterdir() if p.is_file() and p.suffix.lower() in VIDEO_EXTENSIONS) if inbox.is_dir() else []
    if not paths:
        report["notes"].append("inbox está vacío: copia aquí los videos originales")
    elif "ffprobe" in report["tools"]:
        for path in paths:
            if path.is_symlink():
                report["errors"].append(f"No se inspecciona el enlace simbólico inbox/{path.name}")
                continue
            try:
                report["media"].append(inspect_media(path, project))
            except (RuntimeError, OSError, ValueError, subprocess.TimeoutExpired) as error:
                report["errors"].append(f"inbox/{path.name}: {error}")
    library_root = project / "recursos"
    libraries = sorted(p for p in library_root.rglob("biblioteca_esencial") if p.is_dir() and not p.is_symlink()) if library_root.is_dir() else []
    report["biblioteca_esencial"] = [str(p.relative_to(project)) for p in libraries]
    if not libraries:
        report["notes"].append("Biblioteca Onda pendiente: importa tu ZIP con scripts/import_nucleo.py")
    report["ready_tools"] = not report["errors"]
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--json", action="store_true", help="Mostrar el informe como JSON")
    arguments = parser.parse_args()
    report = check(arguments.root.expanduser().resolve())
    if arguments.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"Proyecto: {report['project']}")
        print(f"Python: {report['python']}")
        for version in report["tools"].values():
            print(version)
        for group in ("filters", "encoders"):
            for name, available in report.get(group, {}).items():
                print(f"{'OK' if available else 'FALTA'}: {name}")
        for media in report["media"]:
            width, height = media["display_dimensions"]
            color = "HDR: convertir a SDR al exportar" if media["hdr_detected"] else "sin HDR HLG/PQ detectado"
            print(f"{media['file']}: {media['duration_seconds']:.2f}s, {width}x{height}, {color}")
        for note in report["notes"]:
            print(f"Pendiente: {note}")
        for error in report["errors"]:
            print(f"ERROR: {error}")
        print("Herramientas listas" if report["ready_tools"] else "Faltan requisitos o hay medios inválidos")
    return 0 if report["ready_tools"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
