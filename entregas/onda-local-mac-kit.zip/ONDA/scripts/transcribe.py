"""Review Spanish speech from local video; output is evidence, not final subtitles."""
from pathlib import Path
import argparse
import json
import subprocess
import numpy as np
import sherpa_onnx

ROOT = Path(__file__).resolve().parents[1]
SAMPLE_RATE = 16000


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('--start', type=float, default=0)
    parser.add_argument('--end', type=float)
    parser.add_argument('--model-dir', type=Path,
                        default=ROOT / 'models' / 'sherpa-onnx-whisper-small')
    parser.add_argument('--out', type=Path)
    parser.add_argument('--threads', type=int, default=3)
    args = parser.parse_args()
    if not args.source.is_file() or args.start < 0:
        raise SystemExit('Provide an existing local source and a non-negative start time')
    if args.end is not None and args.end <= args.start:
        raise SystemExit('--end must be after --start')
    model = args.model_dir
    needed = [model / x for x in ('small-encoder.int8.onnx',
                                 'small-decoder.int8.onnx', 'small-tokens.txt')]
    if not all(p.is_file() for p in needed):
        raise SystemExit('Run scripts/download_asr_model.py to prepare the verified model first')
    command = ['ffmpeg', '-v', 'error', '-nostdin', '-i', str(args.source), '-vn',
               '-af', 'aresample=16000:async=1:first_pts=0:min_hard_comp=0.001',
               '-ar', str(SAMPLE_RATE), '-ac', '1', '-f', 'f32le', 'pipe:1']
    decoded = subprocess.run(command, check=True, capture_output=True).stdout
    audio = np.frombuffer(decoded, dtype='<f4')
    duration = len(audio) / SAMPLE_RATE
    end = min(duration, args.end if args.end is not None else duration)
    if args.start >= end:
        raise SystemExit('Requested speech window is outside the decoded source')
    recognizer = sherpa_onnx.OfflineRecognizer.from_whisper(
        encoder=str(needed[0]), decoder=str(needed[1]), tokens=str(needed[2]),
        language='es', task='transcribe', num_threads=max(1, args.threads), provider='cpu')
    results = []
    cursor = args.start
    while cursor < end:
        boundary = min(cursor + 20, end)
        stream = recognizer.create_stream()
        stream.accept_waveform(SAMPLE_RATE,
                               audio[round(cursor * SAMPLE_RATE):round(boundary * SAMPLE_RATE)])
        recognizer.decode_stream(stream)
        item = {'source_in': cursor, 'source_out': boundary, 'text': stream.result.text}
        results.append(item)
        print(json.dumps(item, ensure_ascii=False), flush=True)
        if boundary == end:
            break
        cursor = boundary - .5
    out = args.out or ROOT / 'work' / 'transcripts' / (args.source.stem + '.json')
    out.parent.mkdir(parents=True, exist_ok=True)
    payload = {'source': str(args.source.resolve()), 'decoded_duration': duration,
               'model': 'official sherpa-onnx Whisper small multilingual', 'language': 'es',
               'timing': 'source audio PTS gaps preserved; phrase review windows, not forced word timestamps',
               'notice': 'Automatic transcription only; no direct listening claimed; merge overlapping windows',
               'windows': results}
    out.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print('Saved:', out)


if __name__ == '__main__':
    main()
