"""Fetch the official Whisper-small ONNX archive with the author's checksum."""
from pathlib import Path
import argparse
import hashlib
import json
import tarfile
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
NAME = 'sherpa-onnx-whisper-small.tar.bz2'
SHA256 = '486a46afbb7ba798507190ffe02fea2dd726049af212e774537efac6afb210a6'
URL = 'https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/' + NAME


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--models-dir', type=Path, default=ROOT / 'models')
    args = parser.parse_args()
    args.models_dir.mkdir(parents=True, exist_ok=True)
    archive = args.models_dir / NAME
    if not archive.exists():
        temporary = archive.with_suffix(archive.suffix + '.part')
        print('Downloading official ASR model; this is a one-time local download.', flush=True)
        with urllib.request.urlopen(URL, timeout=60) as response, temporary.open('wb') as output:
            for block in iter(lambda: response.read(1024 * 1024), b''):
                output.write(block)
        if digest(temporary) != SHA256:
            temporary.unlink()
            raise RuntimeError('Author checksum mismatch; model was not loaded or extracted')
        temporary.replace(archive)
    if digest(archive) != SHA256:
        raise RuntimeError('Cached model checksum mismatch; model was not loaded or extracted')
    model = args.models_dir / 'sherpa-onnx-whisper-small'
    required = [model / name for name in ('small-encoder.int8.onnx',
                                          'small-decoder.int8.onnx', 'small-tokens.txt')]
    if not all(path.is_file() for path in required):
        with tarfile.open(archive) as handle:
            handle.extractall(args.models_dir, filter='data')
    if not all(path.is_file() for path in required):
        raise RuntimeError('The verified archive did not contain the expected model files')
    print(json.dumps({'model': str(model), 'archive_sha256': SHA256,
                      'verified': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
