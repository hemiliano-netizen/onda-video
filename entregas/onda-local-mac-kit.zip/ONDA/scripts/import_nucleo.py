#!/usr/bin/env python3
"""Import the user's Onda core ZIP into recursos, preserving existing files."""
import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import unicodedata
import zipfile
from pathlib import Path, PurePosixPath


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def safe_name(info):
    if "\x00" in info.orig_filename:
        raise ValueError("Nombre con byte NUL en el ZIP")
    name = info.filename.replace("\\", "/")
    if "\x00" in name or name.startswith("/") or re.match(r"^[A-Za-z]:", name):
        raise ValueError(f"Ruta absoluta o inválida en el ZIP: {info.filename!r}")
    components = name.rstrip("/").split("/")
    if any(part in {"", ".", ".."} for part in components):
        raise ValueError(f"Ruta no segura en el ZIP: {info.filename!r}")
    mode = info.external_attr >> 16
    file_type = stat.S_IFMT(mode)
    if file_type not in {0, stat.S_IFREG, stat.S_IFDIR}:
        raise ValueError(f"Enlace simbólico o archivo especial en el ZIP: {info.filename!r}")
    if info.flag_bits & 1:
        raise ValueError("No se importan archivos ZIP cifrados")
    return Path(*PurePosixPath(name).parts)


def check_destination(destination, relative):
    target = destination / relative
    for path in [target, *target.parents]:
        if path == destination.parent:
            break
        if path.is_symlink():
            raise ValueError(f"Se preserva el enlace simbólico existente; no se importará encima: {relative}")
        if path != target and path.exists() and not path.is_dir():
            raise ValueError(f"Un archivo existente bloquea un directorio del ZIP: {relative}")
    if not target.resolve().is_relative_to(destination.resolve()):
        raise ValueError(f"El archivo sale del directorio recursos: {relative}")
    return target


def path_key(path):
    return unicodedata.normalize("NFC", str(path)).casefold()


def import_zip(zip_path, project):
    destination = project / "recursos"
    if destination.is_symlink():
        raise ValueError("recursos no puede ser un enlace simbólico")
    if destination.exists() and not destination.is_dir():
        raise ValueError("recursos ya existe como archivo; no se modificará")
    zip_hash = digest(zip_path)
    records = []
    project.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as archive:
        entries = []
        used = set()
        for info in archive.infolist():
            relative = safe_name(info)
            key = path_key(relative)
            if key in used:
                raise ValueError(f"Ruta duplicada o ambigua en el ZIP: {relative}")
            used.add(key)
            target = check_destination(destination, relative)
            if info.is_dir() and target.exists() and not target.is_dir():
                raise ValueError(f"Un archivo existente bloquea un directorio del ZIP: {relative}")
            if not info.is_dir() and target.exists() and not target.is_file():
                raise ValueError(f"Un directorio existente bloquea un archivo del ZIP: {relative}")
            entries.append((info, relative))
        file_paths = {path_key(relative) for info, relative in entries if not info.is_dir()}
        needed_directories = {path_key(parent) for _, relative in entries for parent in relative.parents
                              if parent != Path(".")}
        conflicts = file_paths & needed_directories
        if conflicts:
            raise ValueError(f"Un archivo del ZIP también se usa como directorio: {sorted(conflicts)[0]}")
        with tempfile.TemporaryDirectory(prefix=".onda-nucleo-", dir=project) as temporary:
            staged = Path(temporary)
            # Read every member first; ZipFile checks CRCs before any original is replaced.
            for index, (info, relative) in enumerate(entries):
                if info.is_dir():
                    continue
                stage = staged / str(index)
                with archive.open(info) as source, stage.open("xb") as output:
                    shutil.copyfileobj(source, output, length=1024 * 1024)
                if stage.stat().st_size != info.file_size:
                    raise ValueError(f"Tamaño incorrecto en el ZIP: {relative}")
                records.append({"path": str(relative), "bytes": info.file_size,
                                "sha256": digest(stage), "stage": str(stage)})
            destination.mkdir(parents=True, exist_ok=True)
            for record in records:
                relative = Path(record["path"])
                target = check_destination(destination, relative)
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.exists():
                    record["status"] = "preserved_identical" if digest(target) == record["sha256"] else "preserved_different"
                    record["existing_sha256"] = digest(target)
                else:
                    # Hard linking staged bytes commits a complete file without replacing another file.
                    try:
                        os.link(record["stage"], target)
                        record["status"] = "imported"
                    except FileExistsError:
                        record["status"] = "preserved_identical" if digest(target) == record["sha256"] else "preserved_different"
                        record["existing_sha256"] = digest(target)
                del record["stage"]
    libraries = sorted(p for p in destination.rglob("biblioteca_esencial") if p.is_dir() and not p.is_symlink())
    summary = {"source_zip": zip_path.name, "source_sha256": zip_hash,
               "destination": "recursos", "files": records,
               "biblioteca_esencial": [str(p.relative_to(project)) for p in libraries],
               "counts": {status: sum(r["status"] == status for r in records)
                          for status in ("imported", "preserved_identical", "preserved_different")}}
    manifest = destination / f".onda-import-{zip_hash[:16]}.json"
    if not manifest.exists():
        with manifest.open("x", encoding="utf-8") as handle:
            json.dump(summary, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    summary["manifest"] = str(manifest.relative_to(project))
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--path", type=Path, help="Ruta al ZIP núcleo que ya tienes")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--json", action="store_true", help="Mostrar también el manifiesto completo en JSON")
    arguments = parser.parse_args()
    project = arguments.root.expanduser().resolve()
    zip_path = (arguments.path or project / "ONDA_CODEX_NUCLEO_MENOS_32MB.zip").expanduser().resolve()
    if not zip_path.is_file():
        print("No se encontró el ZIP. Colócalo en la raíz del proyecto o indica --path '/ruta/al/archivo.zip'.", file=sys.stderr)
        return 1
    try:
        summary = import_zip(zip_path, project)
    except (ValueError, OSError, zipfile.BadZipFile, RuntimeError) as error:
        print(f"No se importó el núcleo: {error}", file=sys.stderr)
        return 1
    if arguments.json:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    else:
        counts = summary["counts"]
        print(f"Núcleo importado: {counts['imported']} archivos nuevos, "
              f"{counts['preserved_identical']} idénticos conservados, "
              f"{counts['preserved_different']} existentes distintos conservados.")
        for library in summary["biblioteca_esencial"]:
            print(f"Biblioteca Onda: {library}")
        print(f"Manifiesto: {summary['manifest']}")
    if not summary["biblioteca_esencial"]:
        print("Aviso: el ZIP no contiene una carpeta biblioteca_esencial.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
