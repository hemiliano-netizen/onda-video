# Validación de estos helpers

Comprobado en el entorno cloud Linux con Python 3.12 y FFmpeg 7.1.5. La instalación con Homebrew y la ejecución en el Mac del usuario quedan pendientes de validarse allí.

- `check_environment.py`: identifica FFmpeg/FFprobe, los cuatro filtros requeridos y los codificadores H.264/AAC. Con una copia temporal de un original iPhone de 163.127.753 bytes identificó HEVC de 10 bits, HLG, giro de −90° y dimensiones de reproducción de 2160×3840. Solo inspeccionó metadatos; no modificó ni convirtió el video.
- `import_nucleo.py`: importó los 73 archivos del ZIP núcleo autorizado en una carpeta temporal y encontró `recursos/biblioteca_esencial`. Una segunda importación conservó los 73 archivos idénticos; un archivo existente distinto también se conservó.
- Extracción: se rechazaron rutas absolutas, traversal con separadores Unix/Windows, nombres NUL, symlinks, colisiones de mayúsculas y Unicode de Mac, conflictos de archivo/directorio y datos con CRC incorrecto. Los rechazos se comprobaron antes de importar esos archivos.
- `download_asr_model.py`: confirmó SHA-256 del archivo oficial ya descargado y la presencia de los tres archivos del modelo. No se duplicó la descarga de 610 MB.
- `transcribe.py`: decodificó y transcribió una ventana real de 4.233333 s de una fuente anterior con Whisper small; produjo un JSON con los límites solicitados. Se comprobó funcionamiento, no exactitud palabra por palabra; sigue siendo necesaria la revisión editorial.
- `setup_mac.sh`: pasó `bash -n`. No se ejecutó Homebrew en el cloud ni se instalaron herramientas del sistema para simular un Mac.

Estas comprobaciones no validan la edición pendiente de los tres videos nuevos. Los originales, núcleo, pesos ASR y medios usados en pruebas no forman parte del kit.
