# Encargo pendiente

El usuario pide unir estos tres videos nuevos en un clip Onda de **menos de 26 segundos**, con el criterio de la pieza aprobada el 6 de octubre de 2026:

1. 🔥Giveaway iPhone 18pro 🔥_clip_2_31_07-2_33_00.mp4
2. VID20261005200839.mp4
3. VID20261005200327.mp4

Conserva los nombres originales reales del disco; el primer nombre puede tener espacios adicionales. Los videos aún no se pudieron inspeccionar en el chat cloud, porque la herramienta de adjuntos limita la transferencia a 32 MiB. Ninguna afirmación del kit presupone su duración, personas, discurso, producto o contenido.

Ahora se trabaja con los originales locales en inbox/. Son fuentes distintas de los videos de la ganadora de ayer: no reutilices sus tomas, voz, nombre o identidad como si fueran estos nuevos archivos.

Abrir con el anuncio en live si el contenido lo confirma; seguir con gestos de entrega/unboxing y testimonio seleccionados por sentido. Subtítulos Fraunces, gráfico Onda con foley, reacción/meme visible si encaja y una sola cortinilla. Evitar cenitales innecesarios y colas no verbales. Duración objetivo 24–25.5 s, límite real <26 s. Entregar MP4 versionado en salida/.
