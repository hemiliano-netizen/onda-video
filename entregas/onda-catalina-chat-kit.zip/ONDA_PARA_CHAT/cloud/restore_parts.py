#!/usr/bin/env python3
"""Restore Onda's independently uploadable ZIP parts; Python 3.12 stdlib only."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import struct
import sys
import tempfile
import unicodedata
import zipfile
import zlib

PART_LIMIT = 32 * 1024 * 1024
PAYLOAD_LIMIT = 30 * 1024 * 1024
METADATA_LIMIT = 4096
MAX_PARTS = 4096
MAX_VIDEOS = 4096
CHUNK = 1024 * 1024
EXTENSIONS = {".mp4", ".mov", ".mkv", ".m4v"}
FIELDS = {"job_id", "part_index", "part_total", "archive_bytes", "archive_sha256",
          "payload_bytes", "payload_sha256"}


class RestoreError(Exception):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


def fail(code: str, message: str):
    raise RestoreError(code, message)


def regular(info: zipfile.ZipInfo, label: str):
    kind = stat.S_IFMT(info.external_attr >> 16)
    if info.is_dir() or kind not in (0, stat.S_IFREG) or info.external_attr & 0x10:
        fail("unsafe_member", f"{label}: miembro no regular o enlace: {info.orig_filename!r}")
    if info.flag_bits & 1:
        fail("encrypted", f"{label}: los ZIP cifrados no están admitidos")
    if info.compress_type != zipfile.ZIP_STORED:
        fail("compression", f"{label}: se requiere ZIP STORE, sin compresión")
    if info.compress_size != info.file_size:
        fail("zip_size", f"{label}: tamaños incompatibles con ZIP STORE")


def small_eocd_count(path: Path) -> int:
    """Read the real EOCD before ZipFile allocates its directory entries."""
    size = path.stat().st_size
    with path.open("rb") as stream:
        stream.seek(max(0, size - 65557))
        tail = stream.read()
    pos = tail.rfind(b"PK\x05\x06")
    while pos >= 0:
        if pos + 22 <= len(tail):
            data = struct.unpack_from("<4s4H2IH", tail, pos)
            if pos + 22 + data[-1] == len(tail):
                if data[1] or data[2] or data[3] != data[4]:
                    fail("multipart_zip", f"{path.name!r}: ZIP multidisco no admitido")
                return data[4]
        pos = tail.rfind(b"PK\x05\x06", 0, pos)
    fail("bad_zip", f"{path.name!r}: final de ZIP ausente o incompleto")


def metadata(raw: bytes, label: str) -> dict:
    if len(raw) > METADATA_LIMIT:
        fail("metadata_size", f"{label}: ONDA_PART.txt excede {METADATA_LIMIT} bytes")
    try:
        lines = raw.decode("ascii").splitlines()
    except UnicodeDecodeError:
        fail("metadata", f"{label}: ONDA_PART.txt debe ser ASCII")
    if not lines or lines[0] != "ONDA_PART_V1":
        fail("metadata", f"{label}: falta cabecera ONDA_PART_V1")
    values = {}
    for line in lines[1:]:
        if not line or line.count("=") != 1:
            fail("metadata", f"{label}: línea de metadatos inválida")
        key, value = line.split("=", 1)
        if key not in FIELDS or key in values or not value or value != value.strip():
            fail("metadata", f"{label}: campo desconocido, repetido o vacío: {key!r}")
        values[key] = value
    if values.keys() != FIELDS:
        fail("metadata", f"{label}: campos incompletos en ONDA_PART.txt")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", values["job_id"], re.ASCII):
        fail("job_id", f"{label}: job_id debe contener solo letras, números, _ o -")
    for key in ("part_index", "part_total", "archive_bytes", "payload_bytes"):
        if not re.fullmatch(r"[0-9]{1,20}", values[key], re.ASCII):
            fail("metadata", f"{label}: {key} debe ser entero decimal positivo")
        values[key] = int(values[key])
        if values[key] <= 0:
            fail("metadata", f"{label}: {key} debe ser mayor que cero")
    if not 1 <= values["part_index"] <= values["part_total"] <= MAX_PARTS:
        fail("part_index", f"{label}: índice o total fuera de 1..{MAX_PARTS}")
    for key in ("archive_sha256", "payload_sha256"):
        if not re.fullmatch(r"[0-9a-fA-F]{64}", values[key], re.ASCII):
            fail("metadata", f"{label}: {key} debe ser SHA-256 hexadecimal de 64 caracteres")
        values[key] = values[key].lower()
    return values


@dataclass
class Part:
    path: Path
    values: dict
    fingerprint: tuple


def fingerprint(path: Path):
    s = path.stat()
    return s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns


def inspect_part(path: Path) -> Part:
    label = repr(path.name)
    if not path.is_file():
        fail("part_path", f"{label}: no es un archivo de parte accesible")
    if path.stat().st_size > PART_LIMIT:
        fail("part_size", f"{label}: ZIP de parte excede 32 MiB")
    if small_eocd_count(path) != 2:
        fail("part_members", f"{label}: se requieren exactamente payload.bin y ONDA_PART.txt")
    with zipfile.ZipFile(path) as zf:
        infos = zf.infolist()
        if len(infos) != 2 or {x.orig_filename for x in infos} != {"payload.bin", "ONDA_PART.txt"}:
            fail("part_members", f"{label}: se requieren exactamente payload.bin y ONDA_PART.txt")
        for info in infos:
            regular(info, label)
        head = zf.getinfo("ONDA_PART.txt")
        payload = zf.getinfo("payload.bin")
        if head.file_size > METADATA_LIMIT:
            fail("metadata_size", f"{label}: ONDA_PART.txt demasiado grande")
        if payload.file_size > PAYLOAD_LIMIT:
            fail("payload_size", f"{label}: payload.bin excede 30 MiB")
        values = metadata(zf.read(head), label)
        if payload.file_size != values["payload_bytes"]:
            fail("payload_size", f"{label}: payload_bytes no coincide con payload.bin")
    return Part(path, values, fingerprint(path))


def check_set(parts: list[Part]) -> list[Part]:
    first = parts[0].values
    seen = {}
    for p in parts:
        m = p.values
        if m["job_id"] != first["job_id"]:
            fail("mixed_job", "Las partes pertenecen a distintos job_id")
        for key in ("part_total", "archive_bytes", "archive_sha256"):
            if m[key] != first[key]:
                fail("mixed_archive", f"{p.path.name!r}: propiedad {key} difiere entre partes")
        i = m["part_index"]
        if i in seen:
            fail("duplicate_part", f"Parte {i} repetida: {seen[i].name!r} y {p.path.name!r}")
        seen[i] = p.path
    missing = sorted(set(range(1, first["part_total"] + 1)) - seen.keys())
    if missing:
        fail("missing_parts", f"Faltan partes: {missing[:20]}" + (" ..." if len(missing) > 20 else ""))
    if sum(p.values["payload_bytes"] for p in parts) != first["archive_bytes"]:
        fail("archive_size", "Suma de payload_bytes no coincide con archive_bytes")
    return sorted(parts, key=lambda p: p.values["part_index"])


def assemble(parts: list[Part], destination: Path):
    digest = hashlib.sha256()
    total = 0
    with destination.open("xb") as out:
        for p in parts:
            if fingerprint(p.path) != p.fingerprint:
                fail("part_changed", f"{p.path.name!r}: la parte cambió durante la restauración")
            local = hashlib.sha256()
            count = 0
            with zipfile.ZipFile(p.path) as zf, zf.open("payload.bin") as inp:
                while data := inp.read(CHUNK):
                    count += len(data)
                    if count > p.values["payload_bytes"]:
                        fail("payload_size", f"{p.path.name!r}: payload más grande que lo declarado")
                    local.update(data)
                    digest.update(data)
                    out.write(data)
            if count != p.values["payload_bytes"]:
                fail("payload_size", f"{p.path.name!r}: payload incompleto")
            if local.hexdigest() != p.values["payload_sha256"]:
                fail("payload_sha", f"{p.path.name!r}: SHA-256 de payload.bin no coincide")
            total += count
        out.flush()
        os.fsync(out.fileno())
    if total != parts[0].values["archive_bytes"]:
        fail("archive_size", "Tamaño del ZIP reensamblado incorrecto")
    if digest.hexdigest() != parts[0].values["archive_sha256"]:
        fail("archive_sha", "SHA-256 del ZIP reensamblado no coincide")


def unicode_name(info: zipfile.ZipInfo, extra: bytes | None = None) -> tuple[str, bool]:
    original = info.orig_filename
    raw = original.encode("utf-8" if info.flag_bits & 0x800 else "cp437")
    extra = info.extra if extra is None else extra
    name = original
    found = False
    while extra:
        if len(extra) < 4:
            fail("unicode_extra", f"{original!r}: campo ZIP extra incompleto")
        key, size = struct.unpack_from("<HH", extra)
        extra = extra[4:]
        if size > len(extra):
            fail("unicode_extra", f"{original!r}: campo ZIP extra truncado")
        body, extra = extra[:size], extra[size:]
        if key != 0x7075:
            continue
        if found or len(body) < 5 or body[0] != 1:
            fail("unicode_extra", f"{original!r}: Unicode Path 0x7075 inválido o repetido")
        found = True
        if struct.unpack_from("<I", body, 1)[0] != zlib.crc32(raw) & 0xffffffff:
            fail("unicode_extra", f"{original!r}: CRC de Unicode Path 0x7075 no coincide")
        try:
            name = body[5:].decode("utf-8")
        except UnicodeDecodeError:
            fail("unicode_extra", f"{original!r}: nombre Unicode Path no es UTF-8 válido")
    if info.flag_bits & 0x800 and name != original:
        fail("unicode_extra", f"{original!r}: Unicode Path contradice el nombre UTF-8 EFS")
    return name, found


def check_local_unicode(zf: zipfile.ZipFile, info: zipfile.ZipInfo, name: str):
    """Local and central Unicode aliases must agree when both are present."""
    zf.fp.seek(info.header_offset)
    head = zf.fp.read(30)
    if len(head) != 30 or head[:4] != b"PK\x03\x04":
        fail("bad_zip", f"{info.orig_filename!r}: cabecera local ZIP inválida")
    name_size, extra_size = struct.unpack_from("<HH", head, 26)
    zf.fp.read(name_size)
    extra = zf.fp.read(extra_size)
    if len(extra) != extra_size:
        fail("bad_zip", f"{info.orig_filename!r}: campo extra local truncado")
    local_name, present = unicode_name(info, extra)
    if present and local_name != name:
        fail("unicode_extra", f"{info.orig_filename!r}: alias Unicode local y central contradictorios")


def safe_name(name: str):
    portable = unicodedata.normalize("NFKC", name)
    if not name or name in (".", "..") or name[-1] in (" ", "."):
        fail("unsafe_name", f"Nombre de archivo no seguro: {name!r}")
    if any(c in portable for c in '/\\:< >|?*'.replace(" ", "")) or name.startswith(("/", "\\")):
        fail("unsafe_name", f"Solo se admiten nombres planos, sin rutas: {name!r}")
    if any(unicodedata.category(c) in ("Cc", "Cs") or c in '\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069' for c in name):
        fail("unsafe_name", f"Nombre con caracteres de control: {name!r}")
    if len(name.encode("utf-8")) > 255:
        fail("unsafe_name", f"Nombre supera 255 bytes UTF-8: {name!r}")
    if Path(name).suffix.casefold() not in EXTENSIONS:
        fail("unsupported_file", f"Extensión no admitida: {name!r}; solo MP4/MOV/MKV/M4V")


def extract_archive(archive: Path, originals: Path) -> list[dict]:
    count = small_eocd_count(archive)
    if count != 0xffff and not 1 <= count <= MAX_VIDEOS:
        fail("archive_members", f"El ZIP original debe contener 1..{MAX_VIDEOS} vídeos")
    records = []
    with zipfile.ZipFile(archive) as zf:
        infos = zf.infolist()
        if not 1 <= len(infos) <= MAX_VIDEOS:
            fail("archive_members", f"El ZIP original debe contener 1..{MAX_VIDEOS} vídeos")
        seen = set()
        raw_seen = set()
        entries = []
        for info in infos:
            regular(info, "ZIP original")
            safe_name(info.orig_filename)
            name, _ = unicode_name(info)
            check_local_unicode(zf, info, name)
            safe_name(name)
            key = unicodedata.normalize("NFKC", name).casefold()
            raw_key = unicodedata.normalize("NFKC", info.orig_filename).casefold()
            if key in seen or raw_key in raw_seen:
                fail("name_collision", f"Nombres repetidos o colisión Unicode/mayúsculas: {name!r}")
            seen.add(key)
            raw_seen.add(raw_key)
            entries.append((info, name))
        total = sum(info.file_size for info, _ in entries)
        if shutil.disk_usage(archive.parent).free < total + 8 * 1024 * 1024:
            fail("no_space", "Espacio libre insuficiente para extraer originales")
        originals.mkdir(mode=0o700)
        for info, name in entries:
            digest = hashlib.sha256()
            count = 0
            with zf.open(info) as inp, (originals / name).open("xb") as out:
                while data := inp.read(CHUNK):
                    count += len(data)
                    if count > info.file_size:
                        fail("video_size", f"{name!r}: vídeo mayor que lo declarado")
                    digest.update(data)
                    out.write(data)
                out.flush()
                os.fsync(out.fileno())
            if count != info.file_size:
                fail("video_size", f"{name!r}: vídeo incompleto")
            records.append({"source_filename": name, "zip_decoded_filename": info.orig_filename,
                            "output_filename": name, "relative_path": "originales/" + name,
                            "bytes": count, "sha256": digest.hexdigest(),
                            "zip_crc32": f"{info.CRC:08x}"})
    return records


def restore(paths: list[Path], output: Path, keep_archive: bool) -> Path:
    if len(paths) > MAX_PARTS:
        fail("part_total", f"Demasiadas partes; máximo {MAX_PARTS}")
    parts = check_set([inspect_part(p) for p in paths])
    meta = parts[0].values
    output.mkdir(parents=True, exist_ok=True)
    if not output.is_dir() or output.is_symlink():
        fail("output_path", "--output debe ser un directorio real, no un enlace")
    target = output / meta["job_id"]
    if os.path.lexists(target):
        fail("output_exists", f"Destino ya existe; no se sobrescribe: {str(target)!r}")
    if shutil.disk_usage(output).free < 2 * meta["archive_bytes"] + 8 * 1024 * 1024:
        fail("no_space", "Espacio insuficiente para ZIP temporal y originales; no se ha extraído nada")
    stage = Path(tempfile.mkdtemp(prefix=".onda-restaurando-", dir=output))
    claimed = False
    try:
        archive = stage / "originales.zip"
        assemble(parts, archive)
        videos = extract_archive(archive, stage / "originales")
        manifest = {"format": "ONDA_RESTORE_V1", "status": "complete", "job_id": meta["job_id"],
                    "archive_bytes": meta["archive_bytes"], "archive_sha256": meta["archive_sha256"],
                    "archive_retained": keep_archive, "archive_filename": "originales.zip" if keep_archive else None,
                    "part_total": meta["part_total"], "original_bytes": sum(v["bytes"] for v in videos),
                    "videos": videos, "parts": [{"filename": p.path.name,
                       "part_index": p.values["part_index"], "payload_bytes": p.values["payload_bytes"],
                       "payload_sha256": p.values["payload_sha256"]} for p in parts],
                    "verification": "ZIP STORE, CRC-32 de cada miembro, SHA-256 de partes y ZIP completo verificados"}
        with (stage / "manifest.json").open("x", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        # Exclusive mkdir prevents replacement even of an existing empty job directory.
        # Complete originals are published by rename; manifest is the final commit marker.
        try:
            target.mkdir(mode=0o700)
        except FileExistsError:
            fail("output_exists", f"Destino apareció durante la restauración; no se sobrescribe: {str(target)!r}")
        claimed = True
        os.rename(stage / "originales", target / "originales")
        if keep_archive:
            os.rename(archive, target / "originales.zip")
        os.rename(stage / "manifest.json", target / "manifest.json")
        return target
    except BaseException:
        if claimed:
            shutil.rmtree(target)
        raise
    finally:
        shutil.rmtree(stage)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path,
                        help="Directorio base; crea job_id/originales sin sobrescribir")
    parser.add_argument("--keep-archive", action="store_true", help="Conserva también originales.zip verificado")
    parser.add_argument("parts", nargs="+", type=Path, help="ZIP de partes, en cualquier orden")
    args = parser.parse_args()
    try:
        target = restore(args.parts, args.output, args.keep_archive)
    except RestoreError as exc:
        print(f"ERROR [{exc.code}]: {exc}", file=sys.stderr)
        return 2
    except (zipfile.BadZipFile, EOFError, UnicodeError, NotImplementedError) as exc:
        print(f"ERROR [zip_corrupt]: ZIP inválido o CRC incorrecto: {exc}", file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"ERROR [io]: {exc}", file=sys.stderr)
        return 2
    print(json.dumps({"status": "restored", "job_directory": str(target),
                      "originals": str(target / "originales"),
                      "manifest": str(target / "manifest.json")}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
