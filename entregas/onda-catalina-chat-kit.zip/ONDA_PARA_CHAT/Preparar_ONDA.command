#!/bin/bash
# Double-click on macOS; all work is performed by the native helper.
set -u
runner_path="${BASH_SOURCE[0]}"
if [[ "$runner_path" == */* ]]; then
  runner_directory="${runner_path%/*}"
else
  runner_directory="."
fi
if ! cd "$runner_directory"; then
  echo "No se pudo abrir la carpeta del preparador." >&2
  exit 1
fi
/bin/bash "$PWD/scripts/prepare_onda.sh" "$@"
result=$?
if [[ "$result" -ne 0 && "$#" -eq 0 && -t 0 ]]; then
  echo "Presiona Enter para cerrar esta ventana."
  IFS= read -r ignored
fi
exit "$result"
