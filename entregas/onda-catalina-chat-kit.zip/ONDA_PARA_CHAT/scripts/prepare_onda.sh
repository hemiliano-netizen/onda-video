#!/bin/bash
# Native macOS Catalina / Bash 3.2. No installers, media conversion or uploads.
set -euo pipefail
export LC_COLLATE=C

payload_limit=31457280
transfer_limit=33554432
mode="ui"
output_base=""
selected_files=()
temporary=""
job_output=""
completed=false

fail() {
  printf '%s\n' "$1" >&2
  exit 1
}

cleanup() {
  result=$?
  trap - EXIT HUP INT TERM
  if [[ -n "$temporary" && -d "$temporary" ]]; then
    rm -rf -- "$temporary"
  fi
  if [[ "$result" -ne 0 && -n "$job_output" && -d "$job_output" && "$completed" != true ]]; then
    printf 'Preparación incompleta. No adjuntes la carpeta parcial: %s\n' "$job_output" >&2
  fi
  exit "$result"
}
trap cleanup EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM

while [[ "$#" -gt 0 ]]; do
  case "$1" in
    --files)
      mode="files"
      shift
      while [[ "$#" -gt 0 && "$1" != "--output" ]]; do
        selected_files[${#selected_files[@]}]="$1"
        shift
      done
      ;;
    --output)
      [[ "$#" -ge 2 ]] || fail "Falta la carpeta después de --output."
      output_base="$2"
      shift 2
      ;;
    --help|-h)
      printf '%s\n' "Doble clic: selecciona tus videos y adjunta los paquetes creados." \
        "Modo terminal: bash scripts/prepare_onda.sh --output CARPETA --files VIDEO..."
      exit 0
      ;;
    *) fail "Opción desconocida. Usa --help para ver el modo terminal." ;;
  esac
done

for required in zip split shasum wc mktemp mkdir rm mv date uname tr; do
  command -v "$required" >/dev/null 2>&1 || fail "Falta una herramienta nativa: $required."
done
temporary="$(mktemp -d "${TMPDIR:-/tmp}/onda-chat.XXXXXXXX")"

if [[ "$mode" == "ui" ]]; then
  [[ "$(uname -s)" == "Darwin" ]] || fail "El selector es para Mac. En terminal usa --files y --output."
  file_list="$temporary/selected-files.bin"
  printf '%s\n' "Selecciona los videos originales en la ventana que se abrirá."
  if ! /usr/bin/osascript - "$file_list" <<'APPLESCRIPT'
on run arguments
    set outputPath to item 1 of arguments
    set chosenFiles to choose file with prompt "Selecciona tus videos originales (MP4, MOV, MKV o M4V). Puedes elegir varios." with multiple selections allowed
    set outputHandle to open for access (POSIX file outputPath) with write permission
    try
        set eof of outputHandle to 0
        repeat with chosenFile in chosenFiles
            set filePath to POSIX path of (chosenFile as alias)
            write (filePath & (ASCII character 0)) to outputHandle as «class utf8»
        end repeat
        close access outputHandle
    on error errorMessage number errorNumber
        try
            close access outputHandle
        end try
        error errorMessage number errorNumber
    end try
end run
APPLESCRIPT
  then
    fail "Selección cancelada o no disponible. No se modificaron tus originales."
  fi
  while IFS= read -r -d '' selected_file; do
    selected_files[${#selected_files[@]}]="$selected_file"
  done < "$file_list"
fi

[[ "${#selected_files[@]}" -gt 0 ]] || fail "No se seleccionaron videos."
basenames=()
basename_keys=()
index=0
for selected_file in "${selected_files[@]}"; do
  if [[ "$selected_file" != /* ]]; then
    selected_file="$PWD/$selected_file"
  fi
  [[ -f "$selected_file" && -r "$selected_file" ]] || fail "Un video seleccionado no existe o no se puede leer."
  case "$selected_file" in
    *.[mM][pP]4|*.[mM][oO][vV]|*.[mM][kK][vV]|*.[mM]4[vV]) ;;
    *) fail "Selecciona solamente videos MP4, MOV, MKV o M4V." ;;
  esac
  basename="${selected_file##*/}"
  basename_key="$(printf '%s' "$basename" | tr '[:upper:]' '[:lower:]')"
  for previous_key in "${basename_keys[@]+${basename_keys[@]}}"; do
    [[ "$basename_key" != "$previous_key" ]] || fail "Hay dos videos con el mismo nombre. Selecciónalos en tandas separadas."
  done
  basenames[${#basenames[@]}]="$basename"
  basename_keys[${#basename_keys[@]}]="$basename_key"
  selected_files[$index]="$selected_file"
  index=$((index + 1))
done

if [[ -z "$output_base" ]]; then
  output_base="$HOME/Desktop/ONDA-PARA-CHAT"
elif [[ "$output_base" != /* ]]; then
  output_base="$PWD/$output_base"
fi
job_id="$(date -u '+%Y%m%dT%H%M%SZ')-$$-${RANDOM}${RANDOM}"
job_output="$output_base/$job_id"
mkdir -p "$output_base"
mkdir "$job_output" || fail "No se pudo crear una carpeta nueva para los paquetes."

hash_file() {
  local checksum_line
  checksum_line="$(shasum -a 256 "$1")"
  checksum_line="${checksum_line#\\}"
  printf '%s' "${checksum_line%% *}"
}

archive="$temporary/originales.zip"
printf '%s\n' "Preparando los originales completos, sin cambiar su calidad…"
zip -q -0 -j "$archive" "${selected_files[@]}"
archive_bytes="$(wc -c < "$archive")"
archive_bytes=$((archive_bytes))
archive_sha256="$(hash_file "$archive")"
[[ "$archive_sha256" =~ ^[a-f0-9]{64}$ ]] || fail "No se pudo verificar el paquete original."
part_total=$(((archive_bytes + payload_limit - 1) / payload_limit))
mkdir "$temporary/chunks" "$temporary/part"
# BSD split on Catalina supports -a and -b, but not GNU's numeric -d.
split -b "$payload_limit" -a 4 "$archive" "$temporary/chunks/chunk-"
printf 'Creando %s paquetes para adjuntar en este chat…\n' "$part_total"

part_index=0
for chunk in "$temporary/chunks"/chunk-*; do
  [[ -f "$chunk" ]] || fail "No se pudo dividir el paquete original."
  part_index=$((part_index + 1))
  mv "$chunk" "$temporary/part/payload.bin"
  payload_bytes="$(wc -c < "$temporary/part/payload.bin")"
  payload_bytes=$((payload_bytes))
  payload_sha256="$(hash_file "$temporary/part/payload.bin")"
  [[ "$payload_bytes" -le "$payload_limit" ]] || fail "Una parte supera el tamaño permitido."
  [[ "$payload_sha256" =~ ^[a-f0-9]{64}$ ]] || fail "No se pudo verificar una parte."
  metadata="$temporary/part/ONDA_PART.txt"
  printf 'ONDA_PART_V1\njob_id=%s\npart_index=%s\npart_total=%s\narchive_bytes=%s\narchive_sha256=%s\npayload_bytes=%s\npayload_sha256=%s\n' \
    "$job_id" "$part_index" "$part_total" "$archive_bytes" "$archive_sha256" "$payload_bytes" "$payload_sha256" > "$metadata"
  printf -v part_name 'ONDA-%s-%03d-de-%03d.zip' "$job_id" "$part_index" "$part_total"
  package="$job_output/$part_name"
  zip -q -0 -j "$package" "$temporary/part/payload.bin" "$metadata"
  package_bytes="$(wc -c < "$package")"
  [[ "$((package_bytes))" -lt "$transfer_limit" ]] || fail "Un paquete supera el límite de adjuntos."
  printf 'Paquete %s de %s listo.\n' "$part_index" "$part_total"
done
[[ "$part_index" -eq "$part_total" ]] || fail "No se completaron todas las partes."
printf 'LISTO PARA ADJUNTAR\nAdjunta los %s archivos ZIP de esta carpeta en el chat de Onda.\nLos videos originales están completos y no se modificaron.\n' \
  "$part_total" > "$job_output/LISTO_PARA_ADJUNTAR.txt"
completed=true
printf '\nListo. Adjunta TODOS los %s ZIP de esta carpeta:\n%s\n' "$part_total" "$job_output"
if [[ "$mode" == "ui" && "$(uname -s)" == "Darwin" ]]; then
  /usr/bin/open "$job_output"
fi
