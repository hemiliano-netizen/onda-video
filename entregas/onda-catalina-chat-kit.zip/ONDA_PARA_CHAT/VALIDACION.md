# Validación

- Se comprobó el flujo completo en el entorno cloud Linux: preparar un original autorizado de 163127753 bytes produjo seis ZIP menores de 32 MiB. El restaurador los recibió en orden invertido y recuperó el video con SHA-256 idéntico, sin recodificación.
- Se verificaron tamaño, cabeceras, CRC y hashes de los paquetes y del archivo completo. Partes ausentes o corruptas se rechazan; fuentes y destinos existentes se conservan.
- Se revisó el preparador para Bash 3.2 de Catalina y BSD split. El código no usa la opción GNU split -d, ni Homebrew, FFmpeg o Python en el Mac. Ambos scripts pasaron bash -n y conservan permisos 755 en el ZIP.
- El restaurador se comprobó con nombres UTF-8/InfoZIP, emojis y espacios, rutas no seguras, conflictos de nombres y protección contra sobrescritura. La suite existente tuvo 92 de 94 resultados esperados; los otros dos exigían prohibir nombres reservados exclusivamente en Windows, que son válidos en Catalina y Linux y quedan fuera del alcance.
- La compatibilidad de las utilidades de Catalina se contrastó con las fuentes de Apple: https://github.com/apple-oss-distributions/distribution-macOS/tree/macos-1015 .

El selector AppleScript y la apertura de Finder NO se han ejecutado en un Mac real desde este entorno. Esa interacción se comprobará al abrir el preparador en tu equipo. Esto no cambia la verificación de los bytes del video reconstruido.

Los originales, paquetes de prueba y credenciales no están incluidos en este kit.
